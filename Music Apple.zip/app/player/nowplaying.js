import React, { useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Dimensions, Animated, PanResponder } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Slider from '@react-native-community/slider';
import { useRouter } from 'expo-router';
import PlayerControls from '../../components/PlayerControls';
import { usePlayerStore } from '../../store/usePlayerStore';
import { COLORS, GRADIENTS } from '../../constants/theme';

const { height: SCREEN_HEIGHT } = Dimensions.get('window');

function formatTime(millis) {
  if (!millis) return '0:00';
  const totalSeconds = Math.floor(millis / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
}

export default function NowPlayingScreen() {
  const router = useRouter();
  const { currentSong, position, duration, seekTo, favorites, toggleFavorite } = usePlayerStore();
  const translateY = useRef(new Animated.Value(0)).current;

  // Swipe-down-to-dismiss gesture (minimizes to MiniPlayer)
  const panResponder = useRef(
    PanResponder.create({
      onMoveShouldSetPanResponder: (_, gesture) =>
        gesture.dy > 8 && Math.abs(gesture.dy) > Math.abs(gesture.dx),
      onPanResponderMove: (_, gesture) => {
        if (gesture.dy > 0) translateY.setValue(gesture.dy);
      },
      onPanResponderRelease: (_, gesture) => {
        if (gesture.dy > 120) {
          Animated.timing(translateY, {
            toValue: SCREEN_HEIGHT,
            duration: 200,
            useNativeDriver: true,
          }).start(() => {
            router.back();
            translateY.setValue(0);
          });
        } else {
          Animated.spring(translateY, { toValue: 0, useNativeDriver: true }).start();
        }
      },
    })
  ).current;

  if (!currentSong) {
    return (
      <SafeAreaView style={styles.emptyContainer}>
        <Text style={styles.emptyText}>No song is playing</Text>
      </SafeAreaView>
    );
  }

  const isFavorite = favorites.includes(currentSong.id);

  return (
    <Animated.View style={[styles.flex, { transform: [{ translateY }] }]} {...panResponder.panHandlers}>
      <LinearGradient colors={GRADIENTS.player} style={styles.flex}>
        <SafeAreaView style={styles.flex}>
          {/* Header */}
          <View style={styles.header}>
            <TouchableOpacity onPress={() => router.back()} style={styles.chevron}>
              <Ionicons name="chevron-down" size={28} color={COLORS.text} />
            </TouchableOpacity>
            <Text style={styles.headerTitle}>NOW PLAYING</Text>
            <View style={{ width: 28 }} />
          </View>

          {/* Artwork */}
          <View style={styles.artworkWrapper}>
            <View style={styles.artwork}>
              <Ionicons name="musical-notes" size={90} color="rgba(255,255,255,0.3)" />
            </View>
          </View>

          {/* Title / Artist / Favorite */}
          <View style={styles.titleRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.title} numberOfLines={1}>
                {currentSong.title}
              </Text>
              <Text style={styles.artist} numberOfLines={1}>
                {currentSong.artist}
              </Text>
            </View>
            <TouchableOpacity onPress={() => toggleFavorite(currentSong.id)}>
              <Ionicons
                name={isFavorite ? 'heart' : 'heart-outline'}
                size={26}
                color={isFavorite ? COLORS.primary : COLORS.text}
              />
            </TouchableOpacity>
          </View>

          {/* Progress bar */}
          <View style={styles.progressWrapper}>
            <Slider
              style={{ width: '100%', height: 32 }}
              minimumValue={0}
              maximumValue={duration || 1}
              value={position}
              minimumTrackTintColor={COLORS.text}
              maximumTrackTintColor="rgba(255,255,255,0.3)"
              thumbTintColor={COLORS.text}
              onSlidingComplete={(value) => seekTo(value)}
            />
            <View style={styles.timeRow}>
              <Text style={styles.timeText}>{formatTime(position)}</Text>
              <Text style={styles.timeText}>{formatTime(duration)}</Text>
            </View>
          </View>

          {/* Controls */}
          <View style={styles.controlsWrapper}>
            <PlayerControls size="large" />
          </View>
        </SafeAreaView>
      </LinearGradient>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  emptyContainer: { flex: 1, backgroundColor: COLORS.background, justifyContent: 'center', alignItems: 'center' },
  emptyText: { color: COLORS.textSecondary, fontSize: 16 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingTop: 8,
  },
  chevron: { padding: 4 },
  headerTitle: { color: COLORS.textSecondary, fontSize: 13, fontWeight: '600', letterSpacing: 1 },
  artworkWrapper: { alignItems: 'center', marginTop: 30, paddingHorizontal: 30 },
  artwork: {
    width: '100%',
    aspectRatio: 1,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.5,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: 10 },
  },
  titleRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 30, marginTop: 34 },
  title: { color: COLORS.text, fontSize: 20, fontWeight: '700' },
  artist: { color: COLORS.textSecondary, fontSize: 15, marginTop: 4 },
  progressWrapper: { paddingHorizontal: 26, marginTop: 20 },
  timeRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: -6 },
  timeText: { color: COLORS.textSecondary, fontSize: 12 },
  controlsWrapper: { paddingHorizontal: 20, marginTop: 30 },
});