import React, { useEffect, useState, useMemo } from 'react';
import { View, Text, StyleSheet, TextInput, FlatList } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import SongItem from '../../components/SongItem';
import { usePlayerStore } from '../../store/usePlayerStore';
import { requestMediaPermission, fetchAllSongs } from '../../utils/musicLibrary';
import { COLORS } from '../../constants/theme';

export default function SearchScreen() {
  const router = useRouter();
  const [query, setQuery] = useState('');
  const [songs, setSongs] = useState([]);
  const { playQueue, currentSong } = usePlayerStore();

  useEffect(() => {
    (async () => {
      const granted = await requestMediaPermission();
      if (granted) setSongs(await fetchAllSongs());
    })();
  }, []);

  const results = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    return songs.filter(
      (s) => s.title.toLowerCase().includes(q) || s.artist.toLowerCase().includes(q)
    );
  }, [query, songs]);

  const handlePlay = (song) => {
    const index = results.findIndex((s) => s.id === song.id);
    playQueue(results, index);
    router.push('/player/nowplaying');
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <Text style={styles.header}>Search</Text>
      <View style={styles.searchBox}>
        <Ionicons name="search" size={18} color={COLORS.textSecondary} />
        <TextInput
          style={styles.input}
          placeholder="Songs, Artists..."
          placeholderTextColor={COLORS.textSecondary}
          value={query}
          onChangeText={setQuery}
        />
      </View>
      <FlatList
        data={results}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <SongItem song={item} isPlaying={currentSong?.id === item.id} onPress={() => handlePlay(item)} />
        )}
        contentContainerStyle={{ paddingBottom: 160 }}
        ListEmptyComponent={
          query.trim() ? <Text style={styles.emptyText}>No results for "{query}"</Text> : null
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  header: { color: COLORS.text, fontSize: 32, fontWeight: '700', paddingHorizontal: 16, marginTop: 8 },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.card,
    borderRadius: 10,
    marginHorizontal: 16,
    marginTop: 12,
    marginBottom: 8,
    paddingHorizontal: 10,
  },
  input: { flex: 1, color: COLORS.text, paddingVertical: 8, paddingHorizontal: 8, fontSize: 15 },
  emptyText: { color: COLORS.textSecondary, textAlign: 'center', marginTop: 40 },
});