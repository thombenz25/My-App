import React, { useEffect, useState, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Modal,
  TextInput,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import SongItem from '../../components/SongItem';
import { usePlayerStore } from '../../store/usePlayerStore';
import { usePlaylistStore } from '../../store/usePlaylistStore';
import {
  requestMediaPermission,
  fetchAllSongs,
  groupByAlbum,
  groupByArtist,
  pickAudioFiles,
} from '../../utils/musicLibrary';
import { COLORS } from '../../constants/theme';

const TABS = ['Songs', 'Albums', 'Artists', 'Playlists'];
const MANUAL_SONGS_KEY = '@music_player_manual_songs';

export default function LibraryScreen() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState('Songs');
  const [songs, setSongs] = useState([]);
  const [manualSongs, setManualSongs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [newPlaylistName, setNewPlaylistName] = useState('');

  const { playQueue, currentSong } = usePlayerStore();
  const { playlists, createPlaylist } = usePlaylistStore();

  const loadSongs = useCallback(async () => {
    setLoading(true);
    const granted = await requestMediaPermission();
    if (granted) {
      const all = await fetchAllSongs();
      setSongs(all);
    } else {
      Alert.alert('Permission required', 'Please allow media access to see your songs.');
    }
    setLoading(false);
  }, []);

  // Load manually imported songs (backup option via expo-document-picker)
  useEffect(() => {
    (async () => {
      const raw = await AsyncStorage.getItem(MANUAL_SONGS_KEY);
      if (raw) setManualSongs(JSON.parse(raw));
    })();
  }, []);

  useEffect(() => {
    loadSongs();
  }, [loadSongs]);

  const combinedSongs = useMemo(() => [...songs, ...manualSongs], [songs, manualSongs]);

  const handleImport = async () => {
    const picked = await pickAudioFiles();
    if (picked.length === 0) return;
    const updated = [...manualSongs, ...picked];
    setManualSongs(updated);
    await AsyncStorage.setItem(MANUAL_SONGS_KEY, JSON.stringify(updated));
  };

  const handlePlaySong = (song) => {
    const index = combinedSongs.findIndex((s) => s.id === song.id);
    playQueue(combinedSongs, index);
    router.push('/player/nowplaying');
  };

  const handleCreatePlaylist = async () => {
    if (!newPlaylistName.trim()) return;
    await createPlaylist(newPlaylistName.trim());
    setNewPlaylistName('');
    setModalVisible(false);
  };

  const renderContent = () => {
    if (activeTab === 'Songs') {
      return (
        <FlatList
          data={combinedSongs}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <SongItem
              song={item}
              isPlaying={currentSong?.id === item.id}
              onPress={() => handlePlaySong(item)}
            />
          )}
          onRefresh={loadSongs}
          refreshing={loading}
          contentContainerStyle={{ paddingBottom: 160 }}
          ListEmptyComponent={
            !loading && <Text style={styles.emptyText}>No songs found on this device.</Text>
          }
        />
      );
    }

    if (activeTab === 'Albums') {
      const albums = groupByAlbum(combinedSongs);
      return (
        <FlatList
          data={albums}
          keyExtractor={(item) => item.title}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.listRow}
              onPress={() => {
                playQueue(item.songs, 0);
                router.push('/player/nowplaying');
              }}
            >
              <View style={styles.rowIcon}>
                <Ionicons name="albums" size={20} color={COLORS.textSecondary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.rowTitle}>{item.title}</Text>
                <Text style={styles.rowSubtitle}>{item.songs.length} songs</Text>
              </View>
            </TouchableOpacity>
          )}
          contentContainerStyle={{ paddingBottom: 160 }}
        />
      );
    }

    if (activeTab === 'Artists') {
      const artists = groupByArtist(combinedSongs);
      return (
        <FlatList
          data={artists}
          keyExtractor={(item) => item.name}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.listRow}
              onPress={() => {
                playQueue(item.songs, 0);
                router.push('/player/nowplaying');
              }}
            >
              <View style={styles.rowIcon}>
                <Ionicons name="person" size={20} color={COLORS.textSecondary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.rowTitle}>{item.name}</Text>
                <Text style={styles.rowSubtitle}>{item.songs.length} songs</Text>
              </View>
            </TouchableOpacity>
          )}
          contentContainerStyle={{ paddingBottom: 160 }}
        />
      );
    }

    // Playlists tab
    return (
      <FlatList
        data={playlists}
        keyExtractor={(item) => item.id}
        ListHeaderComponent={
          <TouchableOpacity style={styles.newPlaylistBtn} onPress={() => setModalVisible(true)}>
            <Ionicons name="add-circle" size={22} color={COLORS.primary} />
            <Text style={styles.newPlaylistText}>New Playlist</Text>
          </TouchableOpacity>
        }
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.listRow} onPress={() => router.push(`/playlist/${item.id}`)}>
            <View style={styles.rowIcon}>
              <Ionicons name="list" size={20} color={COLORS.textSecondary} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.rowTitle}>{item.name}</Text>
              <Text style={styles.rowSubtitle}>{item.songIds.length} songs</Text>
            </View>
          </TouchableOpacity>
        )}
        contentContainerStyle={{ paddingBottom: 160 }}
      />
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.headerRow}>
        <Text style={styles.header}>Library</Text>
        <TouchableOpacity onPress={handleImport} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Ionicons name="folder-open-outline" size={24} color={COLORS.primary} />
        </TouchableOpacity>
      </View>

      <View style={styles.tabsRow}>
        {TABS.map((tab) => (
          <TouchableOpacity key={tab} onPress={() => setActiveTab(tab)} style={styles.tabBtn}>
            <Text style={[styles.tabText, activeTab === tab && styles.tabTextActive]}>{tab}</Text>
            {activeTab === tab && <View style={styles.tabUnderline} />}
          </TouchableOpacity>
        ))}
      </View>

      {renderContent()}

      <Modal visible={modalVisible} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>New Playlist</Text>
            <TextInput
              style={styles.input}
              placeholder="Playlist name"
              placeholderTextColor={COLORS.textSecondary}
              value={newPlaylistName}
              onChangeText={setNewPlaylistName}
            />
            <View style={styles.modalActions}>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Text style={styles.modalCancel}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={handleCreatePlaylist}>
                <Text style={styles.modalCreate}>Create</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginTop: 8,
  },
  header: { color: COLORS.text, fontSize: 32, fontWeight: '700' },
  tabsRow: { flexDirection: 'row', paddingHorizontal: 16, marginTop: 12, marginBottom: 8 },
  tabBtn: { marginRight: 20, alignItems: 'center' },
  tabText: { color: COLORS.textSecondary, fontSize: 15, fontWeight: '600' },
  tabTextActive: { color: COLORS.text },
  tabUnderline: { height: 2, backgroundColor: COLORS.primary, marginTop: 4, width: '100%' },
  emptyText: { color: COLORS.textSecondary, textAlign: 'center', marginTop: 40 },
  listRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 10 },
  rowIcon: {
    width: 46,
    height: 46,
    borderRadius: 6,
    backgroundColor: COLORS.card,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  rowTitle: { color: COLORS.text, fontSize: 16, fontWeight: '500' },
  rowSubtitle: { color: COLORS.textSecondary, fontSize: 13, marginTop: 2 },
  newPlaylistBtn: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12 },
  newPlaylistText: { color: COLORS.primary, fontSize: 16, fontWeight: '600', marginLeft: 8 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', alignItems: 'center' },
  modalBox: { width: '80%', backgroundColor: COLORS.card, borderRadius: 12, padding: 20 },
  modalTitle: { color: COLORS.text, fontSize: 18, fontWeight: '700', marginBottom: 12 },
  input: { backgroundColor: COLORS.surface, borderRadius: 8, padding: 10, color: COLORS.text, marginBottom: 16 },
  modalActions: { flexDirection: 'row', justifyContent: 'flex-end' },
  modalCancel: { color: COLORS.textSecondary, fontSize: 15, marginRight: 20 },
  modalCreate: { color: COLORS.primary, fontSize: 15, fontWeight: '700' },
});