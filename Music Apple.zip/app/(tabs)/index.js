import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, RefreshControl } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import SongItem from '../../components/SongItem';
import { usePlayerStore } from '../../store/usePlayerStore';
import { requestMediaPermission, fetchAllSongs } from '../../utils/musicLibrary';
import { COLORS, GRADIENTS } from '../../constants/theme';

export default function HomeScreen() {
  const router = useRouter();
  const [songs, setSongs] = useState([]);
  const [loading, setLoading] = useState(true);
  const { playQueue, currentSong, favorites } = usePlayerStore();

  const load = useCallback(async () => {
    setLoading(true);
    const granted = await requestMediaPermission();
    if (granted) {
      const all = await fetchAllSongs();
      setSongs(all);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const recentlyAdded = songs.slice(0, 10);
  const favoriteSongs = songs.filter((s) => favorites.includes(s.id));

  const handlePlay = (song, list) => {
    const index = list.findIndex((s) => s.id === song.id);
    playQueue(list, index);
    router.push('/player/nowplaying');
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <LinearGradient colors={GRADIENTS.dark} style={StyleSheet.absoluteFill} />
      <ScrollView
        contentContainerStyle={{ paddingBottom: 160 }}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={load} tintColor={COLORS.text} />}
      >
        <Text style={styles.header}>For You</Text>

        {favoriteSongs.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Favorites</Text>
            {favoriteSongs.slice(0, 5).map((song) => (
              <SongItem
                key={song.id}
                song={song}
                isPlaying={currentSong?.id === song.id}
                onPress={() => handlePlay(song, favoriteSongs)}
              />
            ))}
          </View>
        )}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recently Added</Text>
          {recentlyAdded.length === 0 && !loading && (
            <Text style={styles.emptyText}>
              No songs found on this device. Add some music and pull to refresh.
            </Text>
          )}
          {recentlyAdded.map((song) => (
            <SongItem
              key={song.id}
              song={song}
              isPlaying={currentSong?.id === song.id}
              onPress={() => handlePlay(song, recentlyAdded)}
            />
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  header: { color: COLORS.text, fontSize: 32, fontWeight: '700', paddingHorizontal: 16, marginTop: 8, marginBottom: 12 },
  section: { marginBottom: 24 },
  sectionTitle: { color: COLORS.text, fontSize: 20, fontWeight: '700', paddingHorizontal: 16, marginBottom: 8 },
  emptyText: { color: COLORS.textSecondary, paddingHorizontal: 16, fontSize: 14, lineHeight: 20 },
});