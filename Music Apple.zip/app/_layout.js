import React, { useEffect } from 'react';
import { Stack, usePathname } from 'expo-router';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import MiniPlayer from '../components/MiniPlayer';
import { usePlayerStore } from '../store/usePlayerStore';
import { usePlaylistStore } from '../store/usePlaylistStore';

// Root layout - runs once for the whole app.
// Sets up audio session, loads persisted data, and renders the global
// navigation stack + persistent MiniPlayer bar.
export default function RootLayout() {
  const pathname = usePathname();
  const initAudio = usePlayerStore((s) => s.initAudio);
  const loadFavorites = usePlayerStore((s) => s.loadFavorites);
  const loadPlaylists = usePlaylistStore((s) => s.loadPlaylists);

  useEffect(() => {
    initAudio();
    loadFavorites();
    loadPlaylists();
  }, []);

  // Hide MiniPlayer while the full-screen Now Playing screen is open
  const hideMiniPlayer = pathname?.startsWith('/player/nowplaying');

  return (
    <SafeAreaProvider>
      <GestureHandlerRootView style={{ flex: 1 }}>
        <StatusBar style="light" />
        <Stack screenOptions={{ headerShown: false }}>
          <Stack.Screen name="(tabs)" />
          <Stack.Screen
            name="player/nowplaying"
            options={{ presentation: 'fullScreenModal', animation: 'slide_from_bottom' }}
          />
          <Stack.Screen
            name="playlist/[id]"
            options={{ presentation: 'card', animation: 'slide_from_right' }}
          />
        </Stack>
        {!hideMiniPlayer && <MiniPlayer />}
      </GestureHandlerRootView>
    </SafeAreaProvider>
  );
}