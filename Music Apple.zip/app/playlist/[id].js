import React, { useEffect, useState, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import SongItem from '../../components/SongItem';
import { usePlaylistStore } from '../../store/usePlaylistStore';
import { usePlayerStore } from '../../store/usePlayerStore';
import { requestMediaPermission, fetchAllSongs } from '../../utils/musicLibrary';
import { COLORS } from '../../constants/theme';

export default function PlaylistDetailScreen() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const { playlists, removeSongFromPlaylist, addSongToPlaylist, deletePlaylist } = usePlaylistStore();
  const { playQueue, currentSong } = usePlayerStore();
  const [allSongs, setAllSongs] = useState([]);
  const [showPicker, setShowPicker] = useState(false);

  const playlist = playlists.find((p) => p.id === id);

  const loadSongs = useCallback(async () => {
    const granted = await requestMediaPermission();
    if (granted) setAllSongs(await fetchAllSongs());
  }, []);

  useEffect(() => {
    loadSongs();
  }, [loadSongs]);

  if (!playlist) {
    return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.emptyText}>Playlist not found</Text>
      </SafeAreaView>
    );
  }

  const playlistSongs = allSongs.filter((s) => playlist.songIds.includes(s.id));
  const availableSongs = allSongs.filter((s) => !playlist.songIds.includes(s.id));

  const handlePlay = (song) => {
    const index = playlistSongs.findIndex((s) => s.id === song.id);
    playQueue(playlistSongs, index);
    router.push('/player/nowplaying');
  };

  const confirmDelete = () => {
    Alert.alert('Delete Playlist', `Delete "${playlist.name}"?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          await deletePlaylist(playlist.id);
          router.back();
        },
      },
    ]);
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="chevron-back" size={26} color={COLORS.text} />
        </TouchableOpacity>
        <Text style={styles.headerTitle} numberOfLines={1}>
          {playlist.name}
        </Text>
        <TouchableOpacity onPress={confirmDelete}>
          <Ionicons name="trash" size={22} color={COLORS.primary} />
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.addBtn} onPress={() => setShowPicker((v) => !v)}>
        <Ionicons name="add-circle" size={20} color={COLORS.primary} />
        <Text style={styles.addBtnText}>{showPicker ? 'Done Adding' : 'Add Songs'}</Text>
      </TouchableOpacity>

      {showPicker ? (
        <FlatList
          data={availableSongs}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <SongItem
              song={item}
              trailingIcon="add-circle-outline"
              onPress={() => addSongToPlaylist(playlist.id, item.id)}
              onMorePress={() => addSongToPlaylist(playlist.id, item.id)}
            />
          )}
          contentContainerStyle={{ paddingBottom: 160 }}
        />
      ) : (
        <FlatList
          data={playlistSongs}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <SongItem
              song={item}
              isPlaying={currentSong?.id === item.id}
              trailingIcon="remove-circle-outline"
              onPress={() => handlePlay(item)}
              onMorePress={() => removeSongFromPlaylist(playlist.id, item.id)}
            />
          )}
          ListEmptyComponent={<Text style={styles.emptyText}>No songs yet. Tap "Add Songs".</Text>}
          contentContainerStyle={{ paddingBottom: 160 }}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  headerTitle: { color: COLORS.text, fontSize: 18, fontWeight: '700', flex: 1, textAlign: 'center' },
  addBtn: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 8 },
  addBtnText: { color: COLORS.primary, marginLeft: 8, fontWeight: '600' },
  emptyText: { color: COLORS.textSecondary, textAlign: 'center', marginTop: 40 },
});