// Handles device media scanning (expo-media-library) and manual file import (expo-document-picker)
import * as MediaLibrary from 'expo-media-library';
import * as DocumentPicker from 'expo-document-picker';

// Request Android/iOS permission to read audio files
export async function requestMediaPermission() {
  const { status } = await MediaLibrary.requestPermissionsAsync();
  return status === 'granted';
}

// Fetch ALL audio files from the device, paginating through MediaLibrary results
export async function fetchAllSongs() {
  let allAssets = [];
  let after = undefined;
  let hasNextPage = true;

  while (hasNextPage) {
    const result = await MediaLibrary.getAssetsAsync({
      mediaType: MediaLibrary.MediaType.audio,
      first: 200,
      after,
      sortBy: MediaLibrary.SortBy.creationTime,
    });
    allAssets = allAssets.concat(result.assets);
    hasNextPage = result.hasNextPage;
    after = result.endCursor;
  }

  // NOTE: expo-media-library does not expose ID3 tags (artist/album/artwork)
  // for audio files - only filesystem metadata. We fall back to filenames.
  // For rich metadata, consider a JS ID3 parser like `music-metadata` reading
  // the file via expo-file-system, or use react-native-track-player's
  // native metadata capabilities (bare workflow only).
  return allAssets.map((asset) => ({
    id: asset.id,
    uri: asset.uri,
    title: asset.filename?.replace(/\.[^/.]+$/, '') || 'Unknown Title',
    artist: 'Unknown Artist',
    album: 'Unknown Album',
    duration: asset.duration ? asset.duration * 1000 : 0,
    artwork: null,
    filename: asset.filename,
  }));
}

export function groupByAlbum(songs) {
  const map = {};
  songs.forEach((song) => {
    const key = song.album || 'Unknown Album';
    if (!map[key]) map[key] = { title: key, artist: song.artist, songs: [] };
    map[key].songs.push(song);
  });
  return Object.values(map);
}

export function groupByArtist(songs) {
  const map = {};
  songs.forEach((song) => {
    const key = song.artist || 'Unknown Artist';
    if (!map[key]) map[key] = { name: key, songs: [] };
    map[key].songs.push(song);
  });
  return Object.values(map);
}

// Backup manual picker (expo-document-picker) - lets user pick audio files
// directly, useful when MediaLibrary scanning is restricted or incomplete.
export async function pickAudioFiles() {
  const result = await DocumentPicker.getDocumentAsync({
    type: 'audio/*',
    multiple: true,
    copyToCacheDirectory: true,
  });

  if (result.canceled) return [];

  const assets = result.assets || [result];
  return assets.map((asset, idx) => ({
    id: `manual-${Date.now()}-${idx}`,
    uri: asset.uri,
    title: asset.name?.replace(/\.[^/.]+$/, '') || 'Imported Song',
    artist: 'Imported',
    album: 'Imported Songs',
    duration: 0,
    artwork: null,
  }));
}