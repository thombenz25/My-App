const { getDefaultConfig } = require('expo/metro-config');

// Standard metro config required by expo-router
const config = getDefaultConfig(__dirname);

module.exports = config;