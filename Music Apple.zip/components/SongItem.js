import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORS } from '../constants/theme';

// Reusable song row used in Home / Library / Search / Playlist screens
export default function SongItem({
  song,
  onPress,
  isPlaying,
  onMorePress,
  trailingIcon = 'ellipsis-horizontal',
}) {
  return (
    <TouchableOpacity style={styles.container} onPress={onPress} activeOpacity={0.7}>
      <View style={styles.artworkPlaceholder}>
        {song.artwork ? (
          <Image source={{ uri: song.artwork }} style={styles.artwork} />
        ) : (
          <Ionicons name="musical-notes" size={22} color={COLORS.textSecondary} />
        )}
      </View>
      <View style={styles.info}>
        <Text style={[styles.title, isPlaying && { color: COLORS.primary }]} numberOfLines={1}>
          {song.title}
        </Text>
        <Text style={styles.artist} numberOfLines={1}>
          {song.artist}
        </Text>
      </View>
      {onMorePress && (
        <TouchableOpacity
          onPress={onMorePress}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <Ionicons name={trailingIcon} size={20} color={COLORS.textSecondary} />
        </TouchableOpacity>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8, paddingHorizontal: 16 },
  artworkPlaceholder: {
    width: 46,
    height: 46,
    borderRadius: 6,
    backgroundColor: COLORS.card,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    overflow: 'hidden',
  },
  artwork: { width: '100%', height: '100%' },
  info: { flex: 1 },
  title: { color: COLORS.text, fontSize: 16, fontWeight: '500' },
  artist: { color: COLORS.textSecondary, fontSize: 13, marginTop: 2 },
});