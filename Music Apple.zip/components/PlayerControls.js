import React from 'react';
import { View, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORS } from '../constants/theme';
import { usePlayerStore } from '../store/usePlayerStore';

// Shared shuffle / prev / play-pause / next / repeat control row
export default function PlayerControls({ size = 'large' }) {
  const {
    isPlaying,
    togglePlayPause,
    playNext,
    playPrevious,
    shuffle,
    toggleShuffle,
    repeatMode,
    cycleRepeatMode,
  } = usePlayerStore();

  const mainIconSize = size === 'large' ? 46 : 32;
  const sideIconSize = size === 'large' ? 32 : 24;

  return (
    <View style={styles.row}>
      <TouchableOpacity onPress={toggleShuffle}>
        <Ionicons name="shuffle" size={22} color={shuffle ? COLORS.primary : COLORS.textSecondary} />
      </TouchableOpacity>

      <TouchableOpacity onPress={playPrevious}>
        <Ionicons name="play-skip-back" size={sideIconSize} color={COLORS.text} />
      </TouchableOpacity>

      <TouchableOpacity onPress={togglePlayPause} style={styles.playButton}>
        <Ionicons
          name={isPlaying ? 'pause-circle' : 'play-circle'}
          size={mainIconSize}
          color={COLORS.text}
        />
      </TouchableOpacity>

      <TouchableOpacity onPress={playNext}>
        <Ionicons name="play-skip-forward" size={sideIconSize} color={COLORS.text} />
      </TouchableOpacity>

      <TouchableOpacity onPress={cycleRepeatMode}>
        <Ionicons
          name={repeatMode === 'one' ? 'repeat-outline' : 'repeat'}
          size={22}
          color={repeatMode !== 'off' ? COLORS.primary : COLORS.textSecondary}
        />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 10,
  },
  playButton: { marginHorizontal: 10 },
});