import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORS } from '../constants/theme';

// Horizontal card used for Album/Artist carousels
export default function AlbumCard({ album, onPress, size = 150 }) {
  return (
    <TouchableOpacity style={[styles.container, { width: size }]} onPress={onPress} activeOpacity={0.8}>
      <View style={[styles.artwork, { width: size, height: size }]}>
        <Ionicons name="albums" size={40} color={COLORS.textSecondary} />
      </View>
      <Text style={styles.title} numberOfLines={1}>
        {album.title}
      </Text>
      <Text style={styles.subtitle} numberOfLines={1}>
        {album.artist}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { marginRight: 14 },
  artwork: {
    borderRadius: 8,
    backgroundColor: COLORS.card,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 6,
  },
  title: { color: COLORS.text, fontSize: 14, fontWeight: '600' },
  subtitle: { color: COLORS.textSecondary, fontSize: 12, marginTop: 2 },
});