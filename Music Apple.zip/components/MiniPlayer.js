import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { usePlayerStore } from '../store/usePlayerStore';
import { COLORS } from '../constants/theme';

// Persistent bottom bar - tap to open full screen player
export default function MiniPlayer() {
  const router = useRouter();
  const { currentSong, isPlaying, togglePlayPause, playNext } = usePlayerStore();

  if (!currentSong) return null; // hidden until something is playing

  return (
    <TouchableOpacity
      activeOpacity={0.9}
      style={styles.container}
      onPress={() => router.push('/player/nowplaying')}
    >
      <LinearGradient colors={['#3a3a3c', '#1c1c1e']} style={styles.gradient}>
        <View style={styles.artwork}>
          <Ionicons name="musical-notes" size={18} color={COLORS.textSecondary} />
        </View>
        <View style={styles.info}>
          <Text style={styles.title} numberOfLines={1}>
            {currentSong.title}
          </Text>
          <Text style={styles.artist} numberOfLines={1}>
            {currentSong.artist}
          </Text>
        </View>
        <TouchableOpacity onPress={togglePlayPause} style={styles.iconBtn}>
          <Ionicons name={isPlaying ? 'pause' : 'play'} size={22} color={COLORS.text} />
        </TouchableOpacity>
        <TouchableOpacity onPress={playNext} style={styles.iconBtn}>
          <Ionicons name="play-skip-forward" size={20} color={COLORS.text} />
        </TouchableOpacity>
      </LinearGradient>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: 8,
    right: 8,
    bottom: 84,
    borderRadius: 10,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: '#000',
    shadowOpacity: 0.4,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 },
  },
  gradient: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8, paddingHorizontal: 10 },
  artwork: {
    width: 38,
    height: 38,
    borderRadius: 6,
    backgroundColor: COLORS.card,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  info: { flex: 1 },
  title: { color: COLORS.text, fontSize: 14, fontWeight: '600' },
  artist: { color: COLORS.textSecondary, fontSize: 12, marginTop: 1 },
  iconBtn: { paddingHorizontal: 8 },
});