// Centralized color palette — inspired by Apple Music dark theme
export const COLORS = {
  background: '#000000',
  surface: '#121212',
  card: '#1C1C1E',
  primary: '#FC3C44',
  secondary: '#FA2D48',
  text: '#FFFFFF',
  textSecondary: '#A0A0A5',
  border: '#2C2C2E',
};

export const GRADIENTS = {
  primary: ['#FA233B', '#FB5C74'],
  dark: ['#1c1c1e', '#000000'],
  player: ['#434346', '#0a0a0a'],
};