// Zustand store managing playback state via expo-av
import { create } from 'zustand';
import { Audio } from 'expo-av';
import AsyncStorage from '@react-native-async-storage/async-storage';

// expo-av Sound instance kept outside React state (not serializable)
let soundObject = null;
const FAVORITES_KEY = '@music_player_favorites';

export const usePlayerStore = create((set, get) => ({
  queue: [],
  currentIndex: -1,
  currentSong: null,
  isPlaying: false,
  isLoading: false,
  position: 0,
  duration: 0,
  shuffle: false,
  repeatMode: 'off', // 'off' | 'all' | 'one'
  favorites: [], // array of song ids

  // ----- Favorites (persisted with AsyncStorage) -----
  loadFavorites: async () => {
    try {
      const raw = await AsyncStorage.getItem(FAVORITES_KEY);
      if (raw) set({ favorites: JSON.parse(raw) });
    } catch (e) {
      console.log('Failed to load favorites', e);
    }
  },

  toggleFavorite: async (songId) => {
    const { favorites } = get();
    const exists = favorites.includes(songId);
    const updated = exists
      ? favorites.filter((id) => id !== songId)
      : [...favorites, songId];
    set({ favorites: updated });
    await AsyncStorage.setItem(FAVORITES_KEY, JSON.stringify(updated));
  },

  // ----- Audio session setup (call once at app start) -----
  initAudio: async () => {
    await Audio.setAudioModeAsync({
      allowsRecordingIOS: false,
      staysActiveInBackground: true,
      playsInSilentModeIOS: true,
      shouldDuckAndroid: true,
      playThroughEarpieceAndroid: false,
    });
  },

  // ----- Queue control -----
  playQueue: async (songs, startIndex = 0) => {
    set({ queue: songs, currentIndex: startIndex });
    await get()._loadAndPlay(songs[startIndex]);
  },

  _loadAndPlay: async (song) => {
    if (!song) return;
    set({ isLoading: true, currentSong: song, position: 0, duration: 0 });
    try {
      if (soundObject) {
        await soundObject.unloadAsync();
        soundObject = null;
      }
      const { sound } = await Audio.Sound.createAsync(
        { uri: song.uri },
        { shouldPlay: true },
        get()._onPlaybackStatusUpdate
      );
      soundObject = sound;
      set({ isPlaying: true, isLoading: false });
    } catch (e) {
      console.log('Error loading sound:', e);
      set({ isLoading: false });
    }
  },

  // Called continuously by expo-av while sound is loaded
  _onPlaybackStatusUpdate: (status) => {
    if (!status.isLoaded) return;
    set({
      position: status.positionMillis || 0,
      duration: status.durationMillis || 0,
      isPlaying: status.isPlaying,
    });
    if (status.didJustFinish) {
      get()._handleTrackFinish();
    }
  },

  _handleTrackFinish: () => {
    const { repeatMode } = get();
    if (repeatMode === 'one') {
      get().seekTo(0);
      soundObject?.playAsync();
    } else {
      get().playNext();
    }
  },

  togglePlayPause: async () => {
    if (!soundObject) return;
    const { isPlaying } = get();
    if (isPlaying) {
      await soundObject.pauseAsync();
      set({ isPlaying: false });
    } else {
      await soundObject.playAsync();
      set({ isPlaying: true });
    }
  },

  playNext: async () => {
    const { queue, currentIndex, shuffle, repeatMode } = get();
    if (queue.length === 0) return;
    let nextIndex;
    if (shuffle) {
      nextIndex = Math.floor(Math.random() * queue.length);
    } else {
      nextIndex = currentIndex + 1;
      if (nextIndex >= queue.length) {
        if (repeatMode === 'all') {
          nextIndex = 0;
        } else {
          await soundObject?.pauseAsync();
          set({ isPlaying: false });
          return;
        }
      }
    }
    set({ currentIndex: nextIndex });
    await get()._loadAndPlay(queue[nextIndex]);
  },

  playPrevious: async () => {
    const { queue, currentIndex, position } = get();
    if (queue.length === 0) return;
    // Restart current song if more than 3s in (like Apple Music)
    if (position > 3000) {
      await get().seekTo(0);
      return;
    }
    const prevIndex = Math.max(currentIndex - 1, 0);
    set({ currentIndex: prevIndex });
    await get()._loadAndPlay(queue[prevIndex]);
  },

  seekTo: async (millis) => {
    if (!soundObject) return;
    await soundObject.setPositionAsync(millis);
    set({ position: millis });
  },

  toggleShuffle: () => set((state) => ({ shuffle: !state.shuffle })),

  cycleRepeatMode: () =>
    set((state) => {
      const modes = ['off', 'all', 'one'];
      const idx = modes.indexOf(state.repeatMode);
      return { repeatMode: modes[(idx + 1) % modes.length] };
    }),
}));