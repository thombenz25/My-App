// Zustand store for playlist CRUD, persisted with AsyncStorage
import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';

const PLAYLISTS_KEY = '@music_player_playlists';

export const usePlaylistStore = create((set, get) => ({
  playlists: [], // { id, name, songIds: [], createdAt }

  loadPlaylists: async () => {
    try {
      const raw = await AsyncStorage.getItem(PLAYLISTS_KEY);
      if (raw) set({ playlists: JSON.parse(raw) });
    } catch (e) {
      console.log('Failed to load playlists', e);
    }
  },

  _persist: async (playlists) => {
    await AsyncStorage.setItem(PLAYLISTS_KEY, JSON.stringify(playlists));
  },

  createPlaylist: async (name) => {
    const newPlaylist = {
      id: Date.now().toString(),
      name,
      songIds: [],
      createdAt: new Date().toISOString(),
    };
    const updated = [...get().playlists, newPlaylist];
    set({ playlists: updated });
    await get()._persist(updated);
    return newPlaylist;
  },

  deletePlaylist: async (id) => {
    const updated = get().playlists.filter((p) => p.id !== id);
    set({ playlists: updated });
    await get()._persist(updated);
  },

  addSongToPlaylist: async (playlistId, songId) => {
    const updated = get().playlists.map((p) =>
      p.id === playlistId && !p.songIds.includes(songId)
        ? { ...p, songIds: [...p.songIds, songId] }
        : p
    );
    set({ playlists: updated });
    await get()._persist(updated);
  },

  removeSongFromPlaylist: async (playlistId, songId) => {
    const updated = get().playlists.map((p) =>
      p.id === playlistId
        ? { ...p, songIds: p.songIds.filter((id) => id !== songId) }
        : p
    );
    set({ playlists: updated });
    await get()._persist(updated);
  },
}));